<?php
	include "connect.php";
?>
<!DOCTYPE HTML>

<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

        <title>DIGIDiBi | Check</title>

        <style>
            .btn {
                background-color: #a6d3e8;
            }
            .btn:hover {
                background-color: #9c87d2;
            }
        </style>
    </head>
    <body>
        <br><br>
        <h1 class="display-1 text-center">Cek Pesanan</h1>
        <section class="vh-100">
            <div class="container-fluid h-custom">
                <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-md-9 col-lg-6 col-xl-5">
                    <img src="images/login-image.png"
                    class="img-fluid" alt="Gambar Login Page Laundry">
                </div>
                <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                    <form name="formcek" method="post" action="">

                    <!-- ID input -->
                    <div class="form-outline mb-4">
                        <label class="form-label" for="form3Example3">ID Pesanan</label>
                        <input name="id" type="text" id="form3Example3" class="form-control form-control-lg"
                        placeholder="Masukkan ID pesanan">
                    </div>

                    <div class="text-center text-lg-start mt-4 pt-2">
                        <input type="submit" name="submit" class="btn btn-lg"
                        style="padding-left: 2.5rem; padding-right: 2.5rem;" value="Cek">
                    </div>

                    </form>
                </div>
                </div>
            </div>
            <?php
            	if(isset($_POST['submit'])){
            		header("Location:?id=$_POST[id]");
            	}
            	if($_GET['id']!=""){
            	$id_pesanan=$_GET['id'];
            	$sql="select akun_laundry.nama_laundry,jenis_paket.harga,jenis_paket.nama_paket,pesanan.* from pesanan join jenis_paket on jenis_paket.id_paket=pesanan.id_paket join akun_laundry on akun_laundry.id=jenis_paket.id_laundry where pesanan.id_pesanan='$id_pesanan'";
                	$query=mysqli_query($conn,$sql);
                	$row=mysqli_fetch_array($query);
                	if($row['id_pesanan']==""){
                		echo "
                			<script>
                				alert('Maaf ID Pesanan tidak ditemukan');
                				document.location='company/../';
                			</script>
                		";
                	}
                	?>
                <br>
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                        	<div class="d-sm-flex align-items-center justify-content-between mb-4">
		                        <h1 class="h3 mb-0 text-gray-800">Rincian Pesanan</h1>
		                    </div>
                            <div class="table-responsive">
                            	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <tr>
                                    	<th>ID Pesanan</th>
                                    	<td><?php echo $row["id_pesanan"]?></td>
                                    </tr>
                                    <tr>
                                    	<th>Nama Pemesan</th>
                                    	<td><?php echo $row["nama_pemesan"]?></td>
                                    </tr>
                                    <tr>
                                    	<th>No. HP</th>
                                    	<td><?php echo $row["no_hp"]?></td>
                                    </tr>
                                    <tr>
                                    	<th>Alamat</th>
                                    	<td><?php echo $row["alamat_pemesan"]?></td>
                                    </tr>
                                    <tr>
                                    	<th>Tempat Laundry</th>
                                    	<td><?php echo $row["nama_laundry"]?></td>
                                    </tr>
                                    <tr>
                                    	<th>Jenis Paket</th>
                                    	<td><?php echo $row["nama_paket"]?></td>
                                    </tr>
                                    <tr>
                                    	<th>Antar Jemput</th>
                                    	<td>
                                    		<?php
                                    			if($row["isantarjemput"]==1) echo "Yes";
                                    			else echo "No";
                                    		?>
                                    	</td>
                                    </tr>
                                    <tr>
                                    	<th>Berat Pesanan (Kg)</th>
                                    	<td><?php echo $row["berat"]?></td>
                                    </tr>
                                    <tr>
                                    	<th>Harga (Rp)</th>
                                    	<td><?php echo $row["berat"]*$row["harga"]?></td>
                                    </tr>
                                    <tr>
                                    	<th>Tanggal Pesan</th>
                                    	<td><?php echo $row["tgl_pesan"]?></td>
                                    </tr>
                                    <tr>
                                    	<th>Tanggal Estimasi</th>
                                    	<td><?php echo $row["estimasi"]?></td>
                                    </tr>
                                    <tr>
                                    	<th>Tanggal Selesai</th>
                                    	<td><?php echo $row["tgl_selesai"]?></td>
                                    </tr>
                                </table>
                                <br>
                        	<div class="d-sm-flex align-items-center justify-content-between mb-4">
		                        <h1 class="h3 mb-0 text-gray-800">Status Pesanan</h1>
		                    </div>
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Waktu</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                	$sql="select progress.*,pesanan.* from pesanan join progress on pesanan.id_pesanan=progress.id_pesanan where progress.id_pesanan='$id_pesanan' order by progress.waktu desc";
                                	$query=mysqli_query($conn,$sql);
                                    while($row = mysqli_fetch_array($query)){
                                    	?>
                                        <tr>
                                            <td><?php echo $row['waktu']?></td>
                                            <td><?php echo $row['status']?></td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
            </div>
            <?php }?>
        </section>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    </body>
</html>
