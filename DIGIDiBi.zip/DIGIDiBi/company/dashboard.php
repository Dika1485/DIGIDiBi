<?php
	include "../connect.php";
	session_start();
	if($_SESSION['id']==""){
		session_destroy();
		header("Location:../company/");
	}
	else{
		if(isLoginSessionExpired()){
			session_destroy();
			echo "
				<script>
					alert('Maaf sesi anda sudah berakhir, Silahkan login kembali!');
					document.location='dashboard.php';
				</script>
			";
		}
	}
	function isLoginSessionExpired(){
		$login_session_duration = 3600; 
		$current_time = time(); 
		if(isset($_SESSION['loggedin_time'])){  
			if(((time() - $_SESSION['loggedin_time']) > $login_session_duration)){ 
				return true; 
			} 
		}
		return false;
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="refresh" content="3600">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DIGIDiBi | Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/style2.css" rel="stylesheet">
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul id="accordionSidebar" class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon">
                    <img src="../images/digidibiwhite.png" width=60>
                </div>
                <div class="sidebar-brand-text mx-3">DIGIDiBi</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <?php
            	if($_GET['page']=="") echo '<li class="nav-item active">';
            	else echo '<li class="nav-item">';
            ?>
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Profil -->
            <?php
            	if($_GET['page']=="profil") echo '<li class="nav-item active">';
            	else echo '<li class="nav-item">';
            ?>
                <a class="nav-link" href="dashboard.php?page=profil">
                    <i class="fas fa-fw fa-store"></i>
                    <span>Profil</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <?php
            	if($_GET['page']=="history") echo '<li class="nav-item active">';
            	else echo '<li class="nav-item">';
            ?>
                <a class="nav-link" href="dashboard.php?page=history">
                    <i class="fas fa-fw fa-table"></i>
                    <span>History</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['username'];?></span>
                                <i class="fas fa-user-circle fa-2x rounded-circle text-gray-300"></i>
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->
                
                <?php
                if($_GET['page']==""){
                	echo '
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card card-btn border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">Data Pesanan</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-cash-register fa-2x text-gray-300"></i>
                                        </div>
                                        <a href="?page=pesanan" class="stretched-link"></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card card-btn border-left-secondary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">Data Jenis Paket</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-box-open fa-2x text-gray-300"></i>
                                        </div>
                                        <a href="?page=paket" class="stretched-link"></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card card-btn border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">Profil</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-store fa-2x text-gray-300"></i>
                                        </div>
                                        <a href="?page=profil" class="stretched-link"></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card card-btn border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">History</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-table fa-2x text-gray-300"></i>
                                        </div>
                                        <a href="?page=history" class="stretched-link"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
                    </div>
                	';
                }
                else if($_GET['page']=="logout"){
                	session_destroy();
                	echo '
                		<script>
                			document.location="../company/";
                		</script>
                	';
                }
                else if($_GET['page']=="history"){
                	$sql="select akun_laundry.id,jenis_paket.*,pesanan.*,progress.* from pesanan join progress on pesanan.id_pesanan=progress.id_pesanan join jenis_paket on jenis_paket.id_paket=pesanan.id_paket join akun_laundry on akun_laundry.id=jenis_paket.id_laundry where akun_laundry.id='$_SESSION[id]' group by progress.id_pesanan order by pesanan.tgl_pesan desc";
                	$query=mysqli_query($conn,$sql);
                	echo '
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">History Pesanan</h1>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID Pesanan</th>
                                            <th>Nama Pemesan</th>
                                            <th>No. HP</th>
                                            <th>Alamat</th>
                                            <th>Berat (kg)</th>
                                            <th>Jenis Paket</th>
                                            <th>Antar-Jemput</th>
                                            <th>Harga (Rp)</th>
                                            <th>Tanggal Pesan</th>
                                            <th>Tanggal Selesai</th>
                                        </tr>
                                    </thead>
                                    <tbody>';
                                    while($row = mysqli_fetch_array($query)){
                                    	?>
                                        <tr>
                                            <td><a href="https://wa.me/+62<?php echo substr($row['no_hp'],1)?>?text=http://localhost/digidibi/?id=<?php echo $row['id_pesanan']?>" target="_blank"><?php echo $row['id_pesanan']?></a></td>
                                            <td><?php echo $row['nama_pemesan']?></td>
                                            <td><?php echo $row['no_hp']?></td>
                                            <td><?php echo $row['alamat_pemesan']?></td>
                                            <td><?php echo $row['berat']?></td>
                                            <td><?php echo $row['nama_paket']?></td>
                                            <td>
                                            	<?php
                                            		if($row['isantarjemput']==1) echo "Yes";
                                            		else echo "No";
	                                            ?>
                                            </td>
                                            <td><?php echo $row['berat']*$row['harga'];?></td>
                                            <td><?php echo $row['tgl_pesan']?></td>
                                            <td><?php echo $row['tgl_selesai']?></td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
            </div>
            <!-- End of Main Content -->
            	<?php
            	}
            	else if($_GET['page']=="profil"){
            		if($_GET['action']=="delete"){
        				$sql="select count(pesanan.id_pesanan) as count from pesanan join jenis_paket on jenis_paket.id_paket=pesanan.id_paket where jenis_paket.id_laundry='$_SESSION[id]' and tgl_selesai is NULL";
        				$query=mysqli_query($conn,$sql);
        				$row=mysqli_fetch_array($query);
        				if($row['count']==0){
        					$sql="select * from jenis_paket where id_laundry='$_SESSION[id]'";
	        				$query=mysqli_query($conn,$sql);
	        				while($rowdelete=mysqli_fetch_array($query)){
	        					$sql="select * from pesanan where id_paket='$rowdelete[id_paket]'";
        						$queryprogress=mysqli_query($conn,$sql);
	        					while($rowprogress=mysqli_fetch_array($queryprogress)){
			                		$sql="delete from progress where id_pesanan='$rowprogress[id_pesanan]'";
			        				mysqli_query($conn,$sql);
			        			}
	        					$sql="delete from pesanan where id_paket='$rowdelete[id_paket]'";
	        					mysqli_query($conn,$sql);
	        				}
        					$sql="delete from jenis_paket where id_laundry='$_SESSION[id]'";
	        				$query=mysqli_query($conn,$sql);
        					$sql="delete from akun_laundry where id='$_SESSION[id]'";
	        				$query=mysqli_query($conn,$sql);
	        				if($query){
	        					session_destroy();
	        					echo '
	        						<script>
	        							alert("Akun berhasil dihapus");
	        							document.location="dashboard.php";
	        						</script>
	        					';
	        				}
        				}
        				else{
        					echo '
        						<script>
        							alert("Maaf akun tidak dapat dihapus, masih ada status pesanan yang belum selesai");
        							document.location="?page=profil";
        						</script>
        					';
        				}
            		}
            		else if(isset($_POST["submit"])) {
        				$username = $_POST["username"];
				        $password = $_POST["password"];
				        $password_confirm = $_POST["confirm"];
				        $nama = $_POST["nama"];
				        $nomor = $_POST["nomor"];
				        $alamat = $_POST["alamat"];
				        if($password != $password_confirm) {
				            echo "<script>alert('Konfirmasi password belum benar! Typo lurr...');document.location='?page=profil';</script>";
				        }
				        else {
				            $sql = "update akun_laundry set username='$username', password='$password', nama_laundry='$nama', no_hp='$nomor', alamat='$alamat' where id='$_SESSION[id]'";
				            $query = mysqli_query($conn, $sql);
				            if ($query) {
				        	$_SESSION['username']=$username;
				        	$_SESSION['password']=$password;
				        	$_SESSION['nama_laundry']=$nama;
				        	$_SESSION['nohp']=$nomor;
				        	$_SESSION['alamat']=$alamat;
			                echo "
			                	<script>
			                		alert('Akun berhasil diupdate!');
				                	document.location='?page=profil';
				                </script>";
            				}
            				else{
            				echo "
			                	<script>
			                		alert('Akun gagal diupdate!');
				                	document.location='?page=profil';
				                </script>";
            				}
			        	}
			    	}
            		else echo '
            		<div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Profil</h1>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                            	<font color=red><i>Tenggat Sewa : '.$_SESSION["tenggat_sewa"].'</i></font>
                            	<div class="text-center text-lg-start mt-4 pt-2">
                            	<form name=formprofil method=post action="?page=profil">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <tr>
                                    	<th>Username</th>
                                    	<td><input type="text" name="username" class="form-control form-control-lg" value="'.$_SESSION["username"].'"></td>
                                    </tr>
                                    <tr>
                                    	<th>Password</th>
                                    	<td><input type="password" name="password" class="form-control form-control-lg" value="'.$_SESSION["password"].'"></td>
                                    </tr>
                                    <tr>
                                    	<th>Confirm Password</th>
                                    	<td><input type="password" name="confirm" class="form-control form-control-lg" value="'.$_SESSION["password"].'"></td>
                                    </tr>
                                    <tr>
                                    <tr>
                                    	<th>Nama Laundry</th>
                                    	<td><input type="text" name="nama" class="form-control form-control-lg" value="'.$_SESSION["nama_laundry"].'"></td>
                                    </tr>
                                    	<th>No. HP</th>
                                    	<td><input type="text" name="nomor" class="form-control form-control-lg" onkeypress="return isNumberKey(event)" value='.$_SESSION["nohp"].' required /></td>
                                    </tr>
                                    <tr>
                                    	<th>Alamat</th>
                                    	<td><textarea name="alamat" class="form-control form-control-lg">'.$_SESSION["alamat"].'</textarea></td>
                                    </tr>
                                </table>
                                <div class="text-center text-lg-start mt-4 pt-2">
                                <input type="submit" class="btn btn-primary btn-lg" name="submit" value="Update" style="padding-left: 2.5rem; padding-right: 2.5rem;">
                                <a href="" data-toggle="modal" data-target="#deleteacc"><button class="btn btn-danger btn-lg" name="delete" style="padding-left: 2.5rem; padding-right: 2.5rem;">Delete Account</button></a>
                                </div>
                                </div>
                                </form>
                                
                    ';
            	}
            	else if($_GET['page']=="pesanan"){
                	$sql="select akun_laundry.id,jenis_paket.nama_paket,jenis_paket.harga,jenis_paket.isetrika,pesanan.*,progress.* from pesanan join progress on pesanan.id_pesanan=progress.id_pesanan join jenis_paket on jenis_paket.id_paket=pesanan.id_paket join akun_laundry on akun_laundry.id=jenis_paket.id_laundry where akun_laundry.id='$_SESSION[id]' and pesanan.tgl_selesai is NULL group by progress.id_pesanan order by progress.waktu";
                	$query=mysqli_query($conn,$sql);
                	if($_GET['action']==""){
                		if(isset($_POST['submit'])){
                			$status=$_POST['status'];
                			$id_pesanan=$_POST['id_pesanan'];
                			switch($status){
                				case "cuci":
                					$next = "Sedang dicuci";
                					break;
                				case "kering":
                					$next = "Pengeringan";
                					break;
                				case "setrika":
                					$next = "Sedang disetrika";
                					break;
                				case "packing":
                					$next = "Packing";
                					break;
                				case "selesai":
                					$next = "Selesai";
                					break;
                			}
	                		$sql="insert into progress values('$id_pesanan',now(),'$next')";
                			$query = mysqli_query($conn, $sql);
                			if ($query) {
                			if($next=="Selesai"){
		                		$sql="update pesanan set tgl_selesai=now() where pesanan.id_pesanan='$id_pesanan'";
    	            			$query = mysqli_query($conn, $sql);
                			}
			                echo "
			                	<script>
			                		alert('Progress berhasil diupdate!');
				                	document.location='?page=pesanan';
				                </script>";
            				}
            				else{
            				echo "
			                	<script>
			                		alert('Progress gagal diupdate!');
				                	document.location='?page=pesanan';
				                </script>";
            				}
                		}
                		?>
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Data Pesanan</h1>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                        	<a href=?page=pesanan&action=tambah>
                        		<button name=tambah class="btn btn-primary btn-lg">Tambah Pesanan</button>
                        	</a>
                            <div class="table-responsive">
                            <br>
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID Pesanan</th>
                                            <th>Nama Pemesan</th>
                                            <th>No. HP</th>
                                            <th>Alamat</th>
                                            <th>Berat (kg)</th>
                                            <th>Jenis Paket</th>
                                            <th>Antar-Jemput</th>
                                            <th>Harga (Rp)</th>
                                            <th>Tanggal Pesan</th>
                                            <th>Tanggal Estimasi</th>
                                            <th>Progress</th>
                                            <th>Tahap Berikutnya</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    while($row = mysqli_fetch_array($query)){
                                    	$isantarjemput="No";
                                    	if($row['isantarjemput']==1) $isantarjemput="Yes";
                                    	?>
                                    	<form name=progress method=post action="?page=pesanan">
                                        <tr>
                                            <td><a href="https://wa.me/+62<?php echo substr($row['no_hp'],1)?>?text=http://localhost/digidibi/?id=<?php echo $row['id_pesanan']?>" target="_blank"><?php echo $row['id_pesanan']?></a></td>
                                            <input type=hidden name="id_pesanan" value="<?php echo $row['id_pesanan']?>">
                                            <td><?php echo $row['nama_pemesan']?></td>
                                            <td><?php echo $row['no_hp']?></td>
                                            <td><?php echo $row['alamat_pemesan']?></td>
                                            <td><?php echo $row['berat']?></td>
                                            <td><?php echo $row['nama_paket']?></td>
                                            <td><?php echo $isantarjemput?></td>
                                            <td><?php echo $row['berat']*$row['harga']?></td>
                                            <td><?php echo $row['tgl_pesan']?></td>
                                            <td><?php echo $row['estimasi']?></td>
                                        <?php
                                        	$sql="select progress.* from progress where progress.id_pesanan='$row[id_pesanan]' order by progress.waktu desc limit 1";
                                        	$querystatus=mysqli_query($conn,$sql);
                                        	$rowstatus=mysqli_fetch_array($querystatus);
                                        	$next="";
                                        	switch($rowstatus['status']) {
                                    		case "Dalam antrian":
                                    			$next="cuci";
                                    			break;
                                    		case "Sedang dicuci":
                                    			$next="kering";
                                    			break;
                                    		case "Pengeringan":
                                    			if($row['isetrika']==1) {
                                    				$next="setrika";
                                    			}
                                    			else{
                                    				$next="packing";
                                    			}
                                    			break;
                                    		case "Sedang disetrika":
                                    			$next="packing";
                                    			break;
                                    		case "Packing":
                                    			$next="selesai";
                                    			break;
                                        	}
                                        ?>
                                            <td><?php echo $rowstatus['status']?></td>
                                            <input type=hidden name="status" value="<?php echo $next?>">
                                            <td align='center'><input type=submit name=submit class="btn btn-lg btn-primary" value="<?php echo $next?>">
                                        </tr>
                                        </form>
                                        <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
            </div>
            <!-- End of Main Content -->
            		<?php
            		}
            		else if($_GET['action']=="tambah"){
            			if(isset($_POST['submit'])){
            				$sql="select akun_laundry.id,jenis_paket.* from jenis_paket join akun_laundry on akun_laundry.id=jenis_paket.id_laundry where akun_laundry.id='$_SESSION[id]' and jenis_paket.nama_paket='$_POST[nama_paket]'";
	                		$query=mysqli_query($conn,$sql);
	                		$row=mysqli_fetch_array($query);
	                		$id_paket=$row['id_paket'];
	                		$antarjemput=0;
	                		$estimasi=$row['estimasi'];
	                		$id="select uuid()";
	                		$query=mysqli_query($conn,$id);
	                		$row=mysqli_fetch_array($query);
	                		$id=$row['uuid()'];
                			if($_POST['antarjemput']=="antarjemput") $antarjemput=1;
	                		$sql="insert into pesanan values('$id','$id_paket','$_POST[nama_pemesan]','$_POST[nohp]','$_POST[berat]','$_POST[alamat]','$antarjemput',now()+interval $estimasi hour,now(),NULL)";
	                		$query=mysqli_query($conn,$sql);
	                		if ($query) {
	                			$sql="insert into progress values('$id',now(),'Dalam antrian')";
	                			$query=mysqli_query($conn,$sql);
			                echo "
			                	<script>
			                		alert('Pesanan berhasil ditambahkan!');
				                	document.location='?page=pesanan';
				                </script>";
            				}
            				else{
            				echo "
			                	<script>
			                		alert('Pesanan gagal ditambahkan!');
				                	document.location='?page=pesanan&action=tambah';
				                </script>";
            				}
	                	}
	                	$sql="select akun_laundry.id,jenis_paket.* from jenis_paket join akun_laundry on akun_laundry.id=jenis_paket.id_laundry where akun_laundry.id='$_SESSION[id]'";
	                	$query=mysqli_query($conn,$sql);
            			?>
            		<div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Tambah Pesanan</h1>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                            	<form name=tambahpesanan method=post action="?page=pesanan&action=tambah">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <tr>
                                    	<th>Nama Paket</th>
                                    	<td>
                                    		<select name="nama_paket" class="form-control form-control-lg" required>
                                    			<?php
                                    				while($row=mysqli_fetch_array($query)){
                                    					?><option><?php echo $row['nama_paket']?></option><?php
                                    				}
                                    			?>
                                    		</select>
                                    	</td>
                                    </tr>
                                    <tr>
                                    	<th>Nama Pemesan</th>
                                    	<td><input type="text" name="nama_pemesan" class="form-control form-control-lg" required></td>
                                    </tr>
                                    <tr>
                                    	<th>No. HP</th>
                                    	<td><input type="text" name="nohp" class="form-control form-control-lg" onkeypress="return isNumberKey(event)" required /></td>
                                    </tr>
                                    <tr>
                                    	<th>Berat (Kg)</th>
                                    	<td><input type="number" name="berat" class="form-control form-control-lg" onkeypress="return isNumberKey(event)" required /></td>
                                    </tr>
                                    <tr>
                                    	<th>Alamat Pemesan</th>
                                    	<td><textarea name="alamat" class="form-control form-control-lg" required></textarea></td>
                                    </tr>
                                    <tr>
                                    	<th>Antar Jemput</th>
                                    	<td><input type="checkbox" name="antarjemput" value="antarjemput" class="form-control form-control-lg" /></td>
                                    </tr>
                                </table>
                                <div class="text-center text-lg-start mt-4 pt-2">
                                <input type="submit" class="btn btn-primary btn-lg" name="submit" value="Tambah" style="padding-left: 2.5rem; padding-right: 2.5rem;">
                                </div>
                                </form>
                    <?php
            		}
            	}
                else if($_GET['page']=="paket"){
                	if($_GET['action']=="update"){
                		if(isset($_POST['submit'])){
                			$nama_paket=$_POST['nama_paket'];
                			$harga=$_POST['harga'];
                			$isetrika=0;
                			$id_paket=$_GET['id'];
                			if($_POST['isetrika']=="isetrika") $isetrika=1;
                			$estimasi=$_POST['estimasi'];
	                		$sql="update jenis_paket set nama_paket='$nama_paket',harga='$harga',isetrika='$isetrika',estimasi='$estimasi' where id_paket='$id_paket' and id_laundry='$_SESSION[id]'";
	                		$query=mysqli_query($conn,$sql);
	                		if ($query) {
			                echo "
			                	<script>
			                		alert('Jenis Paket berhasil diupdate!');
				                	document.location='?page=paket';
				                </script>";
            				}
            				else{
            				echo "
			                	<script>
			                		alert('Jenis Paket gagal diupdate!');
				                	document.location='?page=paket&action=update';
				                </script>";
            				}
	                	}
                		$sql="select jenis_paket.* from jenis_paket where jenis_paket.id_laundry='$_SESSION[id]' and jenis_paket.id_paket='$_GET[id]'";
                		$query=mysqli_query($conn,$sql);
                		$row=mysqli_fetch_array($query);
                		?>
            		<div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Update Jenis Paket</h1>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                            	<form name=updatepaket action="?page=paket&action=update&id=<?php echo $_GET['id'];?>" method=post>
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <tr>
                                    	<th>Nama Paket</th>
                                    	<td><input type="text" name="nama_paket" class="form-control form-control-lg" value="<?php echo $row["nama_paket"]?>"></td>
                                    </tr>
                                    <tr>
                                    	<th>Harga (/Kg)</th>
                                    	<td><input type="number" name="harga" class="form-control form-control-lg" onkeypress="return isNumberKey(event)" value=<?php echo $row["harga"]?> </td>
                                    </tr>
                                    <tr>
                                    	<th>Setrika</th>
                                    	<td><input type="checkbox" name="isetrika" value="isetrika" class="form-control form-control-lg"
                                    	<?php if($row["isetrika"]==1) echo "checked";?>
                                    	></td>
                                    </tr>
                                    <tr>
                                    	<th>Estimasi (Jam)</th>
                                    	<td><input type="number" name="estimasi" class="form-control form-control-lg" onkeypress="return isNumberKey(event)" onkeypress="return isNumberKey(event)" value=<?php echo $row["estimasi"]?> required /></td>
                                    </tr>
                                </table>
                                <div class="text-center text-lg-start mt-4 pt-2">
                                <input type="submit" class="btn btn-primary btn-lg" name="submit" value="Update" style="padding-left: 2.5rem; padding-right: 2.5rem;">
                                </div>
                                </form>
                    <?php
                	}
                	else if($_GET['action']=="tambah"){
                		if(isset($_POST['submit'])){
                			$nama_paket=$_POST['nama_paket'];
                			$harga=$_POST['harga'];
                			$isetrika=0;
                			if($_POST['isetrika']=="isetrika") $isetrika=1;
                			$estimasi=$_POST['estimasi'];
	                		$sql="insert into jenis_paket values(uuid(), '$_SESSION[id]', '$nama_paket', '$harga', '$isetrika', '$estimasi')";
	                		$query=mysqli_query($conn,$sql);
	                		if ($query) {
			                echo "
			                	<script>
			                		alert('Jenis Paket berhasil ditambahkan!');
				                	document.location='?page=paket';
				                </script>";
            				}
            				else{
            				echo "
			                	<script>
			                		alert('Jenis Paket gagal ditambahkan!');
				                	document.location='?page=paket&action=tambah';
				                </script>";
            				}
	                	}
                		echo '
            		<div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Tambah Jenis Paket</h1>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                            	<form name=formpaket method=post action="?page=paket&action=tambah">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <tr>
                                    	<th>Nama Paket</th>
                                    	<td><input type="text" name="nama_paket" class="form-control form-control-lg" required></td>
                                    </tr>
                                    <tr>
                                    	<th>Harga (/Kg)</th>
                                    	<td><input type="number" name="harga" class="form-control form-control-lg" onkeypress="return isNumberKey(event)" required></td>
                                    </tr>
                                    <tr>
                                    	<th>Setrika</th>
                                    	<td><input type="checkbox" name="isetrika" value="isetrika" class="form-control form-control-lg"></td>
                                    </tr>
                                    <tr>
                                    	<th>Estimasi (Jam)</th>
                                    	<td><input type="number" name="estimasi" class="form-control form-control-lg" onkeypress="return isNumberKey(event)" required /></td>
                                    </tr>
                                </table>
                                <div class="text-center text-lg-start mt-4 pt-2">
                                <input type="submit" class="btn btn-primary btn-lg" name="submit" value="Tambah" style="padding-left: 2.5rem; padding-right: 2.5rem;">
                                </div>
                                </form>
                    ';
                	}
                	else if($_GET['action']=="delete"){
                		$sql="select count(pesanan.id_pesanan) as count from pesanan join jenis_paket on jenis_paket.id_paket=pesanan.id_paket where jenis_paket.id_laundry='$_SESSION[id]' and jenis_paket.id_paket='$_GET[id]' and pesanan.tgl_selesai is NULL";
        				$query=mysqli_query($conn,$sql);
        				$row=mysqli_fetch_array($query);
        				if($row['count']==0){
        					$sql="select * from pesanan where id_paket='$_GET[id]'";
        					$query=mysqli_query($conn,$sql);
        					while($row=mysqli_fetch_array($query)){
		                		$sql="delete from progress where id_pesanan='$row[id_pesanan]'";
		        				mysqli_query($conn,$sql);
		        			}
	        				$sql="delete from pesanan where id_paket='$_GET[id]'";
	        				mysqli_query($conn,$sql);
        					$sql="delete from jenis_paket where id_laundry='$_SESSION[id]' and id_paket='$_GET[id]'";
        					$query=mysqli_query($conn,$sql);
	                		if ($query) {
			                echo "
			                	<script>
			                		alert('Jenis Paket berhasil dihapus!');
				                	document.location='?page=paket';
				                </script>";
            				}
            				else{
            				echo "
			                	<script>
			                		alert('Jenis Paket gagal dihapus!');
				                	document.location='?page=paket';
				                </script>";
            				}
            			}
            			else{
        					echo '
        						<script>
        							alert("Maaf jenis paket tidak dapat dihapus, masih ada status pesanan yang belum selesai");
        							document.location="?page=paket";
        						</script>
        					';
        				}
                	}
                	else if($_GET['action']==""){
                	$sql="select akun_laundry.id,jenis_paket.* from jenis_paket join akun_laundry on akun_laundry.id=jenis_paket.id_laundry where akun_laundry.id='$_SESSION[id]' order by jenis_paket.estimasi";
                	$query=mysqli_query($conn,$sql);
                	echo '
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Data Jenis Paket</h1>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                        	<a href=?page=paket&action=tambah>
                        		<button name=tambah class="btn btn-primary btn-lg">Tambah Jenis Paket</button>
                        	</a>
                            <div class="table-responsive">
                            	<br>
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Nama Paket</th>
                                            <th>Harga (/Kg)</th>
                                            <th>Setrika</th>
                                            <th>Estimasi (Jam)</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>';
                                    while($row = mysqli_fetch_array($query)){
                                    	$setrika="No";
                                    	if($row['isetrika']==1) $setrika="Yes";
                                    	echo '
                                        <tr>
                                            <td>'.$row['nama_paket'].'</td>
                                            <td>'.$row['harga'].'</td>
                                            <td>'.$setrika.'</td>
                                            <td>'.$row['estimasi'].'</td>
                                            <td>
                                            	<a href=?page=paket&action=update&id='.$row["id_paket"].'><button type="button" class="btn btn-primary btn-lg">Update</button></a>
                                            	<a href=?page=paket&action=delete&id='.$row["id_paket"].'><button type="button" class="btn btn-danger btn-lg">Delete</button></a>
                                            </td>
                                        </tr>
                                        ';
                                    }
                                    echo '
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
            </div>
            <!-- End of Main Content -->
            	';
            		}
            	}
                ?>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Anda yakin mau logout?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">NO</button>
                    <a class="btn btn-primary" href="?page=logout">YES</a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Delete Account-->
    <div class="modal fade" id="deleteacc" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Anda yakin mau menghapus akun?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">NO</button>
                    <a class="btn btn-primary" href="?page=profil&action=delete">YES</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="../vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../js/demo/chart-area-demo.js"></script>
    <script src="../js/demo/chart-pie-demo.js"></script>
    
    <script>
            function isNumberKey(evt) {
                var charCode = evt.keyCode;
                if (charCode > 31 && (charCode < 48 || charCode > 57)) return false;
                return true;
            }
        </script>

</body>

</html>
