<?php
    include "../connect.php";
    $username = $_POST["username"];
    $password = $_POST["password"];
    $password_confirm = $_POST["password_confirm"];
    $nama = $_POST["nama"];
    $nomor = $_POST["nomor"];
    $alamat = $_POST["alamat"];
?>

<!DOCTYPE HTML>

<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

        <title>DIGIDiBi | Regist Page</title>

        <style>
            body {
                background-color: #c7cad8;
            }
        </style>
    </head>
    <body>
        <br><br>
        <h1 class="display-1 text-center">Registrasi</h1>
        <section class="mt-4">
            <div class="container-md">
                <form action="daftar.php" method="post" name="formulir">
                <div class="row">
                    <div class="col">
                        <div class="form-outline mb-4">
                            <label class="form-label" for="regisUsername">Username</label>
                            <input type="text" id="regisUsername" name="username" class="form-control form-control-lg"
                            placeholder="Masukkan username" value="<?php echo $username?>" required/>
                        </div>
                        <div class="form-outline mb-4">
                            <label class="form-label" for="regisPass">Password</label>
                            <input type="password" id="regisPass" name="password" class="form-control form-control-lg"
                            placeholder="Masukkan password" value="<?php echo $password?>" required/>
                        </div>
                        <div class="form-outline mb-4">
                            <label class="form-label" for="regisPassConf">Konfirmasi Password</label>
                            <input type="password" id="regisPassConf" name="password_confirm" class="form-control form-control-lg"
                            placeholder="Masukkan kembali password" value="<?php echo $password_confirm?>" required/>
                        </div>
                        <?php
                        	if(isset($_POST["submit"])) {
						        if($password != $password_confirm) {
						            echo "<font color=red><i>Konfirmasi password belum benar!</i></font>";
						        }
						        else {
						            $sql = "INSERT INTO akun_laundry VALUES(uuid(), '$username', '$password', '$nama', '$nomor', '$alamat', 0,NULL)";
						            $query = mysqli_query($conn, $sql);
						            if ($query) {
					            	$url="https://wa.me/+6282226536669?text=Halo%2C%20saya%20$username%20mau%20membuat%20Akun%20DIGIDiBi%20dengan%20rincian%20sebagai%20berikut%3A%0AUsername%20%3D%20$username%0ANama%20Laundry%20%3D%20$nama%0ANo.%20HP%20%3D%20$nomor%0AAlamat%20%3D%20$alamat";
					                echo "
					                	<script>
					                		alert('Silahkan melakukan verifikasi dan pembayaran di tab baru untuk pembuatan akun!');
						                	var win=window.open('".$url."','_blank');
						                	win.focus();
						                	document.location='../company/';
						                </script>";
						            }
					    	    }
					    	}
					    ?>
                    </div>
                    <div class="col">
                        <div class="form-outline mb-4">
                            <label class="form-label" for="regisNama">Nama Laundry</label>
                            <input type="text" id="regisNama" name="nama" class="form-control form-control-lg"
                            placeholder="Masukkan nama laundry" value="<?php echo $nama?>" required />
                        </div>
                        <div class="form-outline mb-4">
                            <label class="form-label" for="regisNomor">No. HP</label>
                            <input type="text" id="regisNomor" name="nomor" class="form-control form-control-lg"
                            placeholder="Masukkan nomor handphone" onkeypress="return isNumberKey(event)" value="<?php echo $nomor?>" required />
                        </div>
                        <div class="form-outline mb-4">
                            <label class="form-label" for="regisAlamat">Alamat</label>
                            <textarea id="regisAlamat" name="alamat" class="form-control form-control-lg" rows="3" placeholder="Masukkan alamat" required><?php echo $alamat?></textarea>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col mt-4 text-center">
                        <input type="submit" name="submit" class="btn btn-primary btn-lg w-50" value="Daftar">
                        <p class="small fw-bold mt-2 pt-1 mb-6">Sudah punya akun? <a href="." class="link-danger">Login</a></p>
                    </div>
                </div>
                </form>
            </div>
        </section>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script>
            function isNumberKey(evt) {
                var charCode = evt.keyCode;
                if (charCode > 31 && (charCode < 48 || charCode > 57)) return false;
                return true;
            }
        </script>
    </body>
</html>
