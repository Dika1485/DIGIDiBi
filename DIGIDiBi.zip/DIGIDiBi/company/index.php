<?php
    include "../connect.php";
	session_start();
	if($_SESSION['id']!=""){
		header("Location:dashboard.php");
	}
    if(isset($_POST["submit"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];

        $sql = "SELECT * FROM akun_laundry WHERE username='$username' and password='$password' and verifikasi=1";
        $query = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($query);
        if(($username==$row['username'])&&($password==$row['password'])&&($row['id']!="")&&($row['verifikasi']==1)){
        	if(is_null($row['tenggat_sewa'])==1){
        		$sql="update akun_laundry set tenggat_sewa=now()+interval 1 month where id='$row[id]'";
        		$query=mysqli_query($conn,$sql);
        	}
        	$sql = "SELECT * FROM akun_laundry WHERE username='$username' and password='$password' and verifikasi=1";
	        $query = mysqli_query($conn, $sql);
	        $row = mysqli_fetch_array($query);
        	$sql="select now()<='$row[tenggat_sewa]' as tgl";
        	$query=mysqli_query($conn,$sql);
        	$tgl=mysqli_fetch_array($query);
        	if($tgl['tgl']==1){
				session_start();
		       	$_SESSION['id']=$row['id'];
		       	$_SESSION['username']=$username;
		       	$_SESSION['password']=$password;
		       	$_SESSION['nama_laundry']=$row['nama_laundry'];
		       	$_SESSION['nohp']=$row['no_hp'];
		       	$_SESSION['alamat']=$row['alamat'];
		       	$_SESSION['verifikasi']=$row['verifikasi'];
		       	$_SESSION['tenggat_sewa']=$row['tenggat_sewa'];
				$_SESSION['loggedin_time'] = time();
	       		echo "<script>document.location='dashboard.php'</script>";
	       	}
	       	else{
	       		$sql="select (now()-interval 1 month)>='$row[tenggat_sewa]' as tgl";
        		$query=mysqli_query($conn,$sql);
	        	$tgl=mysqli_fetch_array($query);
	        	if($tgl['tgl']==1){
		        	$sql="select * from jenis_paket where id_laundry='$row[id]'";
		        	$query=mysqli_query($conn,$sql);
		        	while($rowdelete=mysqli_fetch_array($query)){
		        		$sql="select * from pesanan where id_paket='$rowdelete[id_paket]'";
		        		$queryprogress=mysqli_query($conn,$sql);
		        		while($rowprogress=mysqli_fetch_array($queryprogress)){
		               		$sql="delete from progress where id_pesanan='$rowprogress[id_pesanan]'";
		        			mysqli_query($conn,$sql);
			       		}
	        			$sql="delete from pesanan where id_paket='$rowdelete[id_paket]'";
	        			mysqli_query($conn,$sql);
	       			}
        			$sql="delete from jenis_paket where id_laundry='$row[id]'";
        			$query=mysqli_query($conn,$sql);
       				$sql="delete from akun_laundry where id='$row[id]'";
	       			$query=mysqli_query($conn,$sql);
	       			if($query){
	       				echo '
	       					<script>
	       						alert("Akun sudah dihapus!");
	        					document.location="dashboard.php";
	        				</script>
	        			';
	        		}
	        	}
	        	else{
	        		$sql="select '$row[tenggat_sewa]'+interval 1 month as tgl";
        			$query=mysqli_query($conn,$sql);
		        	$tgl=mysqli_fetch_array($query);
		       		$url="https://wa.me/+6282226536669?text=Halo%2C%20saya%20$row[username]%20mau%20melakukan%20verifikasi%20dan%20pembayaran%20sewa%20untuk%20Akun%20DIGIDiBi%20dengan%20rincian%20sebagai%20berikut%3A%0AUsername%20%3D%20$row[username]%0ANama%20Laundry%20%3D%20$row[nama_laundry]%0ANo.%20HP%20%3D%20$row[no_hp]%0AAlamat%20%3D%20$row[alamat]";
		       		echo "
		       			<script>
		       				alert('Sesi sewa sudah kadaluarsa, akun akan dihapus otomatis pada ".$tgl['tgl'].". Silahkan melakukan verifikasi dan pembayaran di tab baru');
		       				var win=window.open('".$url."','_blank');
		       				win.focus();
		       				document.location='../company/';
		       			</script>
		       		";
		       	}
	       	}
	    }
        else {
            echo "<script>alert('Username/Password salah!');document.location='../company/'</script>;";
        }
    }
?>

<!DOCTYPE HTML>

<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

        <title>DIGIDiBi | Login Page</title>

        <style>
            body {
                background-color: #c7cad8;
            }
        </style>
    </head>
    <body>
        <br><br>
        <h1 class="display-1 text-center">Login Page</h1>
        <section class="mt-4">
            <div class="container-fluid h-custom">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-md-9 col-lg-6 col-xl-5">
                        <img src="../images/login-image.png"
                        class="img-fluid" alt="Sample image">
                    </div>
                    <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                        <form action="../company/" method="post" name="formulir">
                        <!-- Email input -->
                        <div class="form-outline mb-4">
                            <label class="form-label" for="loginUsername">Username</label>
                            <input type="text" id="loginUsername" name="username" class="form-control form-control-lg"
                            placeholder="Masukkan username" required/>
                        </div>
                
                        <!-- Password input -->
                        <div class="form-outline mb-3">
                            <label class="form-label" for="loginPass">Password</label>
                            <input type="password" id="loginPass" name="password" class="form-control form-control-lg"
                            placeholder="Masukkan password" required/>
                        </div>

                        <div class="text-center text-lg-start mt-4 pt-2">
                            <input type="submit" class="btn btn-primary btn-lg" name="submit" value="Login" style="padding-left: 2.5rem; padding-right: 2.5rem;">
                            <p class="small fw-bold mt-2 pt-1 mb-0">Belum punya akun? <a href="daftar.php"
                                class="link-danger">Daftar</a></p>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </section>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    </body>
</html>
